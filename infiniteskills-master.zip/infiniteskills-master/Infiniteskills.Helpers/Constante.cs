﻿using System;
namespace Infiniteskills.Helpers
{
    public class EditActionConstant
    {
        public const string NEW = "1";
        public const string EDIT = "2";
        public const string COPY = "4";
        public const string DELETE = "3";
    }
   
}
