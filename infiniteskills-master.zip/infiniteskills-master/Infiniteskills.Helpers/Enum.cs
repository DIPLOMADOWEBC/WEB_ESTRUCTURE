﻿namespace Infiniteskills.Helpers
{
   public enum LabelAlignment
   {
      Left = 0,
      Right = 1
   }
}
