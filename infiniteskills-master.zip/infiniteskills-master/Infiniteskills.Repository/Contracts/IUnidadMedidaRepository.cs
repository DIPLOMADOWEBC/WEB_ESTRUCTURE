﻿using Infiniteskills.Domain;
using Infiniteskills.Infra.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Infiniteskills.Repository
{
    public interface IUnidadMedidaRepository : IRepositoryBase<UnidadMedida>
    {

    }
}
