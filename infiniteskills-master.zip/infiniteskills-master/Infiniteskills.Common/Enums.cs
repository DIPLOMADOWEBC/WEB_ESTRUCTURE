﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Infiniteskills.Common
{
    public enum DTOState
    {
        Added = 0,
        Modified = 1,
        Deleted = 2,
        Unchanged = 3
    }
}
