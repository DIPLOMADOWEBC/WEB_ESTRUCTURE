﻿using System;
namespace Infiniteskills.Common
{
    public class SequenceGeneratorAttribute : Attribute
    {
        public string SequenceName { get; set; }
    }
}
